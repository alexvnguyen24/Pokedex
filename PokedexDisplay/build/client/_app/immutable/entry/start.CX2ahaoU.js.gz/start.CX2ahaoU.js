import{a as t}from"../chunks/entry.D4s9ras4.js";export{t as start};
